<?php
/**
 * v1/helpers.php – gemeinsame Hilfsfunktionen für alle v1-Endpunkte.
 * Wird von index.php einmalig geladen.
 */
declare(strict_types=1);

if (!function_exists('resolveStation')) {
	/**
	 * Station anhand MAC (bevorzugt), dann slug ermitteln.
	 *
	 * @param  PDO         $db
	 * @param  string|null $slug  station_slug aus dem Request
	 * @param  string|null $mac   device_mac aus dem Request (normalisiert: 'aa:bb:cc:dd:ee:ff')
	 * @return array|null  ['id', 'slug', 'name', 'mac'] oder null wenn keine Station zugeordnet werden kann
	 */
	function resolveStation(PDO $db, ?string $slug, ?string $mac = null): ?array
	{
		// 1. Per MAC suchen (eindeutig, hardware-seitig garantiert)
		if ($mac) {
			$st = $db->prepare('SELECT id, slug, name, mac FROM stations WHERE mac = ? LIMIT 1');
			$st->execute([$mac]);
			$row = $st->fetch();
			if ($row) return $row;
		}

		// 2. Per slug suchen (Fallback fuer Geraete ohne MAC)
		if ($slug) {
			$st = $db->prepare('SELECT id, slug, name, mac FROM stations WHERE slug = ? LIMIT 1');
			$st->execute([$slug]);
			$row = $st->fetch();
			if ($row) return $row;
		}

		// 3. Kein Identifier vorhanden
		return null;
	}
}

if (!function_exists('normalizeMac')) {
	/** MAC-Adresse normalisieren: 'A4:CF:12:AB:34:56' → 'a4:cf:12:ab:34:56' */
	function normalizeMac(?string $mac): ?string
	{
		if (!$mac) return null;
		$clean = strtolower(preg_replace('/[^0-9a-fA-F]/', '', $mac));
		if (strlen($clean) !== 12) return null;
		return implode(':', str_split($clean, 2));
	}
}

if (!function_exists('getClientIp')) {
	/** Client-IP ermitteln (auch hinter Proxies) */
	function getClientIp(): string
	{
		foreach (['HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR'] as $key) {
			$ip = $_SERVER[$key] ?? '';
			if ($ip) {
				// Bei X-Forwarded-For die erste (Client-)IP nehmen
				$parts = explode(',', $ip);
				$ip = trim($parts[0]);
				if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
			}
		}
		return 'unknown';
	}
}

if (!function_exists('logSystemEvent')) {
	/**
	 * System-Ereignis in die system_log-Tabelle schreiben.
	 *
	 * @param string $level   'error', 'warning' oder 'info'
	 * @param string $source  'auth', 'db', 'station', 'api', 'router'
	 * @param string $code    Maschinenlesbarer Code, z.B. 'AUTH_FAILED'
	 * @param string $message Menschenlesbare Beschreibung
	 * @param array|null $context Zusatzinfos (wird als JSON gespeichert)
	 */
	function logSystemEvent(string $level, string $source, string $code, string $message = '', ?array $context = null): void
	{
		try {
			$db = getDb();
			$stmt = $db->prepare('
				INSERT INTO system_log (level, source, code, message, context, ip)
				VALUES (:level, :source, :code, :msg, :ctx, :ip)
			');
			$stmt->execute([
				':level'  => $level,
				':source' => $source,
				':code'   => substr($code, 0, 64),
				':msg'    => substr($message, 0, 512),
				':ctx'    => ($context !== null && $context !== []) ? json_encode($context, JSON_UNESCAPED_UNICODE) : null,
				':ip'     => getClientIp(),
			]);
		} catch (\Throwable $e) {
			// Logging darf niemals den normalen Ablauf stören –
			// Fehler beim Loggen werden still ignoriert.
			error_log('SWS system_log failed: ' . $e->getMessage());
		}
	}
}
